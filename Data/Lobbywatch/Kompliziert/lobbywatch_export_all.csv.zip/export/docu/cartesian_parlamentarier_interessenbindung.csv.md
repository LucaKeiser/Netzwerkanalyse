Lobbywatch Export: CSV
======================

Datei: export/cartesian_parlamentarier_interessenbindung.csv  
Datum: 13.11.2021 02:31:01  
Datensatztyp: cartesian  
Exporttyp: Öffentlich / Public  

Herausgeber: Lobbywatch (https://lobbywatch.ch)  

Die Inhalte von Lobbywatch.ch sind lizenziert unter einer Creative Commons Namensnennung - Weitergabe unter gleichen Bedingungen 4.0 International Lizenz. (https://creativecommons.org/licenses/by-sa/4.0/deed.de)

Data are licensed as CC BY-SA


## parlamentarier_interessenbindung (parlamentarier)

Datensatztyp: cartesian

Feld | Beschreibung
- | -
anzeige_name | Der Anzeigename ist eine Kombination anderer Namensfelder. Dieser Name enthält die relevanten Bestandteile zur Anzeige. In der Regel ist der deutsche Name enthalten.
name | Name des Datensatzes. In der Regel ist der deutsche Name enthalten.
id | Technischer Schlüssel des Parlamentariers Technischer Schlüssel
nachname | Nachname des Parlamentariers
vorname | Vornahme des Parlamentariers
vorname_kurz | Alltagsvorname oder gebräuchlicher Spitzname, z.B. Nik für Niklaus
zweiter_vorname | Zweiter Vorname des Parlamentariers
rat_id | Ratszugehörigkeit; Fremdschlüssel des Rates
kanton_id | Kantonszugehörigkeit; Fremdschlüssel des Kantons
kommissionen | Abkürzungen der Kommissionen des Parlamentariers (automatisch erzeugt [in_Kommission Trigger])
partei_id | Fremdschlüssel Partei. Leer bedeutet parteilos.
parteifunktion | Funktion des Parlamentariers in der Partei
fraktion_id | Fraktionszugehörigkeit im nationalen Parlament. Fremdschlüssel.
fraktionsfunktion | Funktion des Parlamentariers in der Fraktion
im_rat_seit | Jahr der Zugehörigkeit zum Parlament
im_rat_bis | Austrittsdatum aus dem Parlament. Leer (NULL) = aktuell im Rat, nicht leer = historischer Eintrag
ratswechsel | Datum in welchem der Parlamentarier den Rat wechselte, in der Regel vom National- in den Ständerat. Leer (NULL) = kein Ratswechsel hat stattgefunden
ratsunterbruch_von | Unterbruch in der Ratstätigkeit von, leer (NULL) = kein Unterbruch
ratsunterbruch_bis | Unterbruch in der Ratstätigkeit bis, leer (NULL) = kein Unterbruch
beruf | Beruf des Parlamentariers
beruf_fr | Beruf des Parlamentariers auf französisch
beruf_interessengruppe_id | Zuordnung (Fremdschlüssel) zu Interessengruppe für den Beruf des Parlamentariers
titel | Titel des Parlamentariers, wird von ws.parlament.ch importiert
aemter | Politische Ämter (importiert von ws.parlament.ch mandate)
weitere_aemter | Zusätzliche Ämter (importiert von ws.parlament.ch additionalMandate)
zivilstand | Zivilstand
anzahl_kinder | Anzahl der Kinder
militaerischer_grad_id | Militärischer Grad, leer (NULL) = kein Militärdienst
geschlecht | Geschlecht des Parlamentariers, M=Mann, F=Frau
geburtstag | Geburtstag des Parlamentariers
photo_dateiname | Photodateiname ohne Erweiterung
photo_dateierweiterung | Erweiterung der Photodatei
photo_dateiname_voll | Photodateiname mit Erweiterung
photo_mime_type | MIME Type des Photos
kleinbild | Bild 44x62 px oder leer.png
sitzplatz | Sitzplatznr im Parlament. Siehe Sitzordnung auf parlament.ch
homepage | Homepage des Parlamentariers
homepage_2 | Zweite Homepage, importiert von ws.parlament.ch
parlament_biografie_id | Biographie ID auf Parlament.ch; Dient zur Herstellung eines Links auf die Parlament.ch Seite des Parlamenteriers. Zudem kann die ID für die automatische Verarbeitung gebraucht werden.
parlament_number | Number Feld auf ws.parlament.ch, wird von ws.parlament.ch importiert, wird z.B. als ID für Photos verwendet.
parlament_interessenbindungen_updated | Datum, wann die Interessenbindungen von ws.parlament.ch zu letzt aktualisiert wurden.
twitter_name | Twittername
instagram_profil | Instagram Username (Profil)
youtube_user | Youtube Username
linkedin_profil_url | URL zum LinkedIn-Profil
xing_profil_name | Profilname in XING (letzter Teil von Link), wird ergänzt mit https://www.xing.com/profile/ zu einem ganzen Link
facebook_name | Facebookname (letzter Teil von Link), wird mit https://www.facebook.com/ zu einem ganzen Link ergänzt
wikipedia | Link zum Wikipedia-Eintrag des Parlamentariers
wikidata_qid | Wikidata Item Q-ID. Wikidata enthält sprachunabhängige Wikipediadaten und stellt eine global gültige ID dar (semantic Web). Die Q-ID wird aufgrund des Wikipedia-Links automatisch gesetzt.
sprache | Sprache des Parlamentariers, wird von ws.parlament.ch importiert
arbeitssprache | Arbeitssprache des Parlamentariers, erhältlich auf parlament.ch
adresse_firma | Wohnadresse des Parlamentariers, falls verfügbar, sonst Postadresse; Adressen erhältlich auf parlament.ch
adresse_plz | Wohnadresse des Parlamentariers, falls verfügbar, sonst Postadresse; Adressen erhältlich auf parlament.ch
adresse_ort | Wohnadresse des Parlamentariers, falls verfügbar, sonst Postadresse; Adressen erhältlich auf parlament.ch
erfasst | Ist der Parlamentarier erfasst? Falls der Parlamentarier beispielsweise nicht mehr zur Wiederwahl antritt und deshalb nicht erfasst wird, kann dieses Feld auf Nein gestellt werden. NULL bedeutet Status unklar.
freigabe_datum | Freigabedatum (Freigabe = Daten sind fertig)
beruf_de | Beruf des Parlamentariers
aktiv | 0/1: Ist der Datensatz zum Zeitpunkt des Exportes aktuell? , 1=aktiv, 0=abgelaufen/historisiert. Der Wert 'aktiv' wird vom 'von'- und 'bis'-Datum berechnet.
geburtstag_unix | Datum als UNIX-Timestap (Sekunden seit 1.1.1970), siehe geburtstag
im_rat_seit_unix | Datum als UNIX-Timestap (Sekunden seit 1.1.1970), siehe im_rat_seit
im_rat_bis_unix | Datum als UNIX-Timestap (Sekunden seit 1.1.1970), siehe im_rat_bis
freigabe_datum_unix | Publikationsdatum als UNIX-Timestap (Sekunden seit 1.1.1970), siehe 'freigabe_datum'
von_unix | Von-Datum als UNIX-Timestap (Sekunden seit 1.1.1970), siehe 'von'
bis_unix | Bis-Datum als UNIX-Timestap (Sekunden seit 1.1.1970), siehe 'bis'
vertretene_bevoelkerung | Brechnetes Feld. Nationalrat: Kantonsbevölkerung / Anzahl Nationalräte des Kantons, Ständerat: Kantonsbevölkerung / Anzahl Ständeräte des Kantons
rat | Kürzel des Rates
kanton | Kantonskürzel
romandie | Gehört dieser Kanton zur Romandie?
rat_de | Kürzel des Rates
kanton_name_de | Deutscher Name des Kantons
rat_fr | Französische Abkürzung
kanton_name_fr | Französischer Name
kommissionen_namen | Deutsche Namen der Kommissionen in welcher der Parlamentarier Einsitz hat. Die Kommssionen sind durch Semikolon ('; ') getrennt.
kommissionen_namen_de | Französische Namen der Kommissionen in welcher der Parlamentarier Einsitz hat. Die Kommssionen sind durch Semikolon ('; ') getrennt.
kommissionen_namen_fr | Deutsche Namen der Kommissionen in welcher der Parlamentarier Einsitz hat. Die Kommssionen sind durch Semikolon ('; ') getrennt.
kommissionen_abkuerzung | Deutsche Kürzel der Kommissionen in welcher der Parlamentarier Einsitz hat. Die Kommssionen sind durch Komma (', ') getrennt.
kommissionen_abkuerzung_de | Deutsche Kürzel der Kommissionen in welcher der Parlamentarier Einsitz hat. Die Kommssionen sind durch Komma (', ') getrennt.
kommissionen_abkuerzung_fr | Französische Kürzel der Kommissionen in welcher der Parlamentarier Einsitz hat. Die Kommssionen sind durch Komma (', ') getrennt.
kommissionen_anzahl | Anzahl der Kommissionen in welcher der Parlamentarier Einsitz hat.
partei | Parteiabkürzung
partei_name | Ausgeschriebener Name der Partei
fraktion | Fraktionsabkürzung
militaerischer_grad | Name des militärischen Grades
partei_de | Parteiabkürzung
partei_name_de | Ausgeschriebener Name der Partei
militaerischer_grad_de | Name des militärischen Grades
partei_fr | Französische Parteiabkürzung
partei_name_fr | Ausgeschriebener französischer Name der Partei
militaerischer_grad_fr | Französischer Name des militärischen Grades
beruf_branche_id | Fremdschlüssel Branche
titel_de | Deutscher Titel der Person, z.B. Dr.
titel_fr | Französischer Titel der Person, z.B. Dr.
parlamentarier_id | Fremdschlüssel Parlamentarier
verguetungstransparenz_beurteilung_stichdatum | Stichdatum der Auswertung der Vergütungstransparenz
verguetungstransparenz_beurteilung | Ist der dieser Parlamentarier transparent bzgl seinen Vergütungen? ja, nein, teilweise (Leer/NULL bedeutet noch nicht eingetragen): NEIN=Minimaltransparenz (= gesetzliches Minimum, bezahlt/ehrenamtlich); TEILWEISE=teilweise transparent (=gesetzl Minimum plus einzelne Entschädigungen als Betrag offengelegt); JA=transparent (=gesetzl. Minimum plus alles Entschädigungen offengelegt; Exkl. Entschädigung aus Hauptberuf)
refreshed_date | Datum er letzten Aktualisierung der MV-Tabelle ('Materialized View')
beschreibung | Bezeichung der Interessenbindung. Möglichst kurz. Wird nicht ausgewertet, jedoch angezeigt.
von | Beginn der Interessenbindung, leer (NULL) = unbekannt
bis | Ende der Interessenbindung, leer (NULL) = aktuell gültig, nicht leer = historischer Eintrag
art | Art der Interessenbindung
funktion_im_gremium | Funktion innerhalb des Gremiums, z.B. Präsident in einem Vorstand einer AG entspricht einem Verwaltungsratspräsidenten, Präsident einer Geschäftsleitung entspricht einem CEO.
deklarationstyp | Ist diese Interessenbindung deklarationspflichtig? Bezeichung der Interessenbindung. Möglichst kurz. Wird nicht ausgewertet, jedoch angezeigt.
status | Status der Interessenbindung
hauptberuflich | Eigene Firma/Haupttätigkeit: Ist diese Interessenbindung hauptberuflich? (Hauptberufliche Interessenbindungen müssen nicht offengelegt werden.)
behoerden_vertreter | Entstand diese Interessenbindung als Behördenvertreter von Amtes wegen? Beispielsweise weil ein Regierungsrat in einem Verwaltungsrat von Amtes wegen Einsitz nimmt.
wirksamkeit | 'tief', 'mittel', 'hoch': Wirksamkeit der Interessenbindung, siehe https://lobbywatch.ch/de/seite/wirksamkeit. Die Wirksamkeit ist eines der primären Resultate von Lobbywach.
wirksamkeit_index | Die Wirksamkeit als Zahl: 1=tief, 2=mittel, 3=hoch
organisation_id | Fremdschlüssel Organisation
verguetung | Jährliche Vergütung CHF für Tätigkeiten aus dieser Interessenbindung, z.B. Entschädigung für Beiratsfunktion.
verguetung_jahr | Jahr auf welche sich die Werte beziehen
verguetung_beschreibung | Beschreibung der Vergütung. Möglichst kurz. Wird nicht ausgewertet, jedoch angezeigt.
name_de | Name der Organisation. Sollte nur juristischem Namen entsprechen, ohne Zusätze, wie Adresse. Deutscher Name des Datensatzes.
uid | UID des Handelsregisters; Schweizweit eindeutige ID (http://www.bfs.admin.ch/bfs/portal/de/index/themen/00/05/blank/03/02.html); Format: CHE-999.999.999
name_fr | Französischer Name Französicher Name des Datensatzes.
ort | Ort der Organisation
rechtsform | Rechtsform der Organisation
rechtsform_handelsregister | Code der Rechtsform des Handelsregister, z.B. 0106 für AG. Das Feld kann importiert werden.
rechtsform_zefix | Numerischer Rechtsformcode von Zefix, z.B. 3 für AG. Das Feld kann importiert werden.
typ | Typ der Organisation. Beziehungen können über Organisation_Beziehung eingegeben werden.
vernehmlassung | Häufigkeit der Teilname an nationalen Vernehmlassungen
interessengruppe1 | Zuteilung der Organisation zur Lobbygruppe (Hauptlobbygruppe der Organisation), deutsch
interessengruppe1_id | Technischer Schlüssel der Interessengruppe
interessengruppe1_branche | Zugehörigkeit zur Branche aufgrund der Hauptlobbygruppe (interessengruppe1) der Organisation, deutsch
interessengruppe1_branche_id | Fremdschlüssel Branche
interessengruppe1_branche_kommission1_abkuerzung | Kürzel der Kommission
interessengruppe1_branche_kommission2_abkuerzung | Kürzel der Kommission
interessengruppe2 | Zuteilung der Organisation zu einer 2. Lobbygruppe, deutsch
interessengruppe2_id | Fremdschlüssel Interessengruppe. 2. Interessengruppe der Organisation.
interessengruppe2_branche | Zugehörigkeit zur Branche aufgrund der 2. Lobbygruppe (interessengruppe2) der Organisation, deutsch
interessengruppe2_branche_id | Fremdschlüssel Branche
interessengruppe2_branche_kommission1_abkuerzung | Kürzel der Kommission
interessengruppe2_branche_kommission2_abkuerzung | Kürzel der Kommission
interessengruppe3 | Zuteilung der Organisation zu einer 3. Lobbygruppe, deutsch
interessengruppe3_id | Fremdschlüssel Interessengruppe. 3. Interessengruppe der Organisation.
interessengruppe3_branche | Zugehörigkeit zur Branche aufgrund der 3. Lobbygruppe (interessengruppe3) der Organisation, deutsch
interessengruppe3_branche_id | Fremdschlüssel Branche
interessengruppe3_branche_kommission1_abkuerzung | Kürzel der Kommission
interessengruppe3_branche_kommission2_abkuerzung | Kürzel der Kommission

