Lobbywatch Export: CSV
======================

Datei: export/flat_zutrittsberechtigung.csv  
Datum: 13.11.2021 02:31:01  
Datensatztyp: flat  
Exporttyp: Öffentlich / Public  

Herausgeber: Lobbywatch (https://lobbywatch.ch)  

Die Inhalte von Lobbywatch.ch sind lizenziert unter einer Creative Commons Namensnennung - Weitergabe unter gleichen Bedingungen 4.0 International Lizenz. (https://creativecommons.org/licenses/by-sa/4.0/deed.de)

Data are licensed as CC BY-SA


## zutrittsberechtigung (zutrittsberechtigung)

Datensatztyp: flat

Feld | Beschreibung
- | -
id | Technischer Schlüssel der Zutrittsberechtigung Technischer Schlüssel
parlamentarier_id | Fremdschlüssel Parlamentarier
person_id | Fremdschlüssel zur zutrittsberechtigten Person
parlamentarier_kommissionen | Abkürzungen der Kommissionen des zugehörigen Parlamentariers (automatisch erzeugt [in_Kommission/zutrittsberechtigung Trigger])
funktion | Funktion der zutrittsberechtigen Person.
funktion_fr | Funktion der zutrittsberechtigen Person auf französisch.
von | Beginn der Zutrittsberechtigung, leer (NULL) = unbekannt
bis | Ende der Zutrittsberechtigung, leer (NULL) = aktuell gültig, nicht leer = historischer Eintrag
updated_by_import | Datum, wann die Zutrittsberechtigung durch einen Import zu letzt aktualisiert wurde.
freigabe_datum | Freigabedatum (Freigabe = Daten sind fertig)
zutrittsberechtigung_parlamentarier_person_unique | Kombination aus parlamentarier_id, person_id und bis muss eindeutig sein. (Fachlicher unique constraint)

