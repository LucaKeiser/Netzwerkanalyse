Lobbywatch Export: Neo4j CSV
============================

Datei: export/relationship_in_kommission.csv  
Datum: 13.11.2021 02:31:01  
Datensatztyp: relationship  
Exporttyp: Öffentlich / Public  

Herausgeber: Lobbywatch (https://lobbywatch.ch)  

Die Inhalte von Lobbywatch.ch sind lizenziert unter einer Creative Commons Namensnennung - Weitergabe unter gleichen Bedingungen 4.0 International Lizenz. (https://creativecommons.org/licenses/by-sa/4.0/deed.de)

Data are licensed as CC BY-SA


## in_kommission (in_kommission)

Datensatztyp: relationship

Feld | Beschreibung
- | -
id | Technischer Schlüssel einer Kommissionszugehörigkeit Technischer Schlüssel
parlamentarier_id | Fremdschlüssel des Parlamentariers
kommission_id | Fremdschlüssel der Kommission
funktion | Funktion des Parlamentariers in der Kommission
parlament_committee_function | committeeFunction von ws.parlament.ch
parlament_committee_function_name | committeeFunctionName von ws.parlament.ch
von | Beginn der Kommissionszugehörigkeit, leer (NULL) = unbekannt
bis | Ende der Kommissionszugehörigkeit, leer (NULL) = aktuell gültig, nicht leer = historischer Eintrag
freigabe_datum | Freigabedatum (Freigabe = Daten sind fertig)
in_kommission_parlamentarier_kommission_funktion_unique | Kombination aus parlamentarier_id, kommission_id, funktion und bis muss eindeutig sein. (Fachlicher unique constraint)

