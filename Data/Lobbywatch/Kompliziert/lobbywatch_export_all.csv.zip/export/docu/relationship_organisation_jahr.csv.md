Lobbywatch Export: Neo4j CSV
============================

Datei: export/relationship_organisation_jahr.csv  
Datum: 13.11.2021 02:31:01  
Datensatztyp: relationship  
Exporttyp: Öffentlich / Public  

Herausgeber: Lobbywatch (https://lobbywatch.ch)  

Die Inhalte von Lobbywatch.ch sind lizenziert unter einer Creative Commons Namensnennung - Weitergabe unter gleichen Bedingungen 4.0 International Lizenz. (https://creativecommons.org/licenses/by-sa/4.0/deed.de)

Data are licensed as CC BY-SA

